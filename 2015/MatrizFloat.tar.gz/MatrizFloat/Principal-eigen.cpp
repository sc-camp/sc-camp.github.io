#include <iostream>
#include <Eigen/Dense>
#include <stdlib.h>

// Eigen library can be downloaded here:
// http://eigen.tuxfamily.org/index.php?title=Main_Page

using namespace std;

int main(int argc, char *argv[]){
	int size;

	if(argc != 2){
		cout << "matriz <tamano>" << endl;
		return 1;
	}
	else{
		size = atoi(argv[1]);
		Eigen::MatrixXf  m1(size, size), m2(size, size), m3;
		m1.setConstant(1.0);
		m2.setConstant(1.0);
		m3.setConstant(0.0);
		m3 = m1 * m2;
		//cout << m3;
		return 0;
	}
}
