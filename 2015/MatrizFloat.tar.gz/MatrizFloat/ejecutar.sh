#!/bin/bash

if [ $# -eq 0 ]
then
	echo Debe pasar el tamano del problema
	exit
fi

aux=`{ time ./matriz $1 >> salida; } |& grep real | cut -d"	" -f2`
mins=`echo $aux | cut -dm -f1`
minsinsec=`echo $mins \* 60 | bc`
secsaux=`echo $aux | cut -dm -f2`
secs=`echo $secsaux | cut -ds -f1`
secs=`echo $minsinsec + $secs | bc`
echo $1 $secs >> salida
