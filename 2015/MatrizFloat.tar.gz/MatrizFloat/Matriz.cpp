#include "Matriz.h"
#include <iostream>

using namespace std;


//Constructor por omisi�n
Matriz::Matriz(){
	filas = 0;
	columnas = 0;
	elementos = NULL;
}

//Constructor por copia
Matriz::Matriz(const Matriz& mat){
	int i,j;
	filas = mat.filas;
	columnas = mat.columnas;
	elementos = new float * [filas];
	for(i=0; i<filas; i++){
		elementos[i] = new float[columnas];
		for(j=0; j<columnas; j++){
			elementos[i][j] = mat.elementos[i][j];
		}
	}
}

Matriz::Matriz(const int f, const int c){
	int i, j;
	filas = f;
	columnas = c;
	elementos = new float * [filas];
	for(i=0; i<filas; i++){
		elementos[i] = new float[columnas];
	}
}

//Destructor
Matriz::~Matriz(){
	delete [] elementos;
}

//M�todos de acceso
float Matriz::Elemento(const int i, const int j){
	return this->elementos[i][j];
}

int Matriz::Filas(){
	return filas;
}

int Matriz::Columnas(){
	return columnas;
}

void Matriz::Mostrar(){
	int i, j;
	for(i=0; i<filas; i++){
		for(j=0; j<columnas; j++){
			cout<<elementos[i][j]<<" ";
		}
		cout<<endl;
	}
}

void Matriz::MostrarDirs(){
	int i, j;
	for(i=0; i<filas; i++){
		for(j=0; j<columnas; j++){
			cout<<&elementos[i][j]<<" ";
		}
		cout<<endl;
	}
}

//M�todos de modificaci�n
void Matriz::asignarElemento(const int i, const int j,
                                   const float val){
	elementos[i][j] = val;
}

void Matriz::Inicializar(const float valor){
	int i, j;
	for(i=0; i<filas; i++){
		for(j=0; j<columnas; j++){
			elementos[i][j] = valor;
		}
	}
}

//M�todos miscelaneos
void Matriz::sumarMatrices(const Matriz& m){
	int i,j;
	if ( filas == m.filas && columnas == m.columnas ){
		for(i=0; i<m.filas; i++)
			for(j=0; j<m.columnas; j++)
				elementos[i][j] += m.elementos[i][j];
	}
}

// m1 = m2;

//Sobrecarga de Operadores
Matriz Matriz::operator = (const Matriz &mat){
	int i,j;
	if(this->filas != 0 || this->columnas != 0)
		delete [] this->elementos;
		
	this->filas = mat.filas;
	this->columnas = mat.columnas;
	this->elementos = new float * [this->filas*this->columnas];
	for(i=0; i<this->filas; i++){
		this->elementos[i] = new float[columnas];
		for(j=0; j<this->columnas; j++){
			this->elementos[i][j] = mat.elementos[i][j];
		}
	}
	return *this;
} 

// m3 = m1 + m2

Matriz Matriz::operator + (const Matriz &m){
	int i,j;
	if ( this->filas == m.filas && this->columnas == m.columnas ){
		Matriz res(m);
		for(i=0; i<m.filas; i++)
			for(j=0; j<m.columnas; j++)
				res.elementos[i][j] += this->elementos[i][j];
		return res;
	}
	else{
		Matriz res;
		return res;
	}
} 

// m3 = m1 * m2;

Matriz Matriz::operator * (const Matriz &m){
	int i,j,k;
	if ( this->columnas == m.filas ){
		Matriz res;
		res.filas = this->filas;
		res.columnas = m.columnas;
		res.elementos = new float * [res.filas];
		for(i=0; i<res.filas; i++)
			res.elementos[i] = new float[res.columnas];
		for(i=0; i<res.filas; i++)
			for(j=0; j<res.columnas; j++)
				for(k=0; k<res.columnas; k++)
					res.elementos[i][j] = res.elementos[i][j] + this->elementos[i][k]*m.elementos[k][j];
		return res;
	}
	else{
		Matriz res;
		return res;
	}
} 

ostream& operator << (ostream& out, const Matriz &m){
	int i,j;
	for(i=0; i<m.filas; i++){
		for(j=0; j<m.columnas; j++){
			//cout << &m.elementos[i][j] << " ";
			cout << m.elementos[i][j] << " ";
		}
		cout << endl;
	}
}

