#!/bin/bash

ls graph*png &> /dev/null

if [ $? -eq 0 ]
then
	lastgrID=`ls graph*png | cut -d. -f1 | cut -dh -f2 | sort -n | tail -1`
	newgrID=`echo $lastgrID + 1 | bc`
else
	newgrID=1
fi
gnuplot << LABEL
set term png
set output "graph${newgrID}.png"
set ylabel "segs"
set xlabel "size"
unset label
set title "Execution Time"
plot "salida" using 1:2 title 'exec time' with lines
exit
LABEL
