#include "Matriz.h"
#include <iostream>
#include <omp.h>
#include <stdlib.h>

using namespace std;

int main(int argc, char *argv[]){
	int size;

	if(argc != 2){
		cout << "matriz <tamano>" << endl;
		return 1;
	}
	else{
		size = atoi(argv[1]);
		Matriz  m1(size, size), m2(size, size), m3;
		m1.Inicializar(1.0);
		m2.Inicializar(1.0);
		m3.Inicializar(0.0);
		m3 = m1 * m2;
		//cout << m3;
		return 0;
	}
}
