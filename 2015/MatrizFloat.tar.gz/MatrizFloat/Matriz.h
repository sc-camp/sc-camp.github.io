#ifndef MATRIZ_H       
#define MATRIZ_H

#include <iostream>
using namespace std;

class Matriz {

	friend ostream& operator << (ostream& out, const Matriz &m);

private:
	int filas, columnas;
	float **elementos;

public:
	//Constructores
	Matriz();
	Matriz(const Matriz&);
	Matriz(const int, const int);
	//Destructor
	~Matriz();

	//Métodos de acceso
	float Elemento(const int, const int);
	int Filas();
	int Columnas();
	void Mostrar();
	void MostrarDirs();

	//Métodos de modificación
	void asignarElemento(const int, const int, const float);
	void Inicializar(const float);
	void Leer();

	//Métodos miscelaneos
	void sumarMatrices(const Matriz& m);

	//Sobrecarga de operadores
	Matriz operator = (const Matriz&);
	Matriz operator + (const Matriz&); 
	Matriz operator * (const Matriz&); 



};
#endif
